﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _2106ACLPrototype.Model
{
    /**
     * Abstract class for files, folders & comments
     */
    abstract class AbstractDataModel
    {
        protected string id { get; set; }
        protected string parentId { get; set; }
        protected int itemType { get; set; }

        public AbstractDataModel(string id, string parentId, int itemType)
        {
            this.id = id;
            this.parentId = parentId;
            this.itemType = itemType;
        }

        public string GetId()
        {
            return this.id;
        }

        public void SetId(string id)
        {
            this.id = id;
        }

        public string GetParentId()
        {
            return this.parentId;
        }

        public void SetParentId(string parentId)
        {
            this.parentId = parentId;
        }

        public int GetItemType()
        {
            return this.itemType;
        }

        public void SetItemType(int itemType)
        {
            this.itemType = itemType;
        }
    }
}
