﻿using _2106ACLPrototype.Model;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using DBLayer;

namespace _2106ACLPrototype.Model
{
    /**
     * This class would receive data from the ACLCoreModel class and split the items into
     * PermissionView and ItemsView and CommentsView. This class would only be used by the ACLCoreModel
     */
    class DataBuilder
    {
        /**
         * Process data retrieved from mongodo. Seperates data list of permssions, items, comments
         * and store it into the ACL
         */
        public void ProcessData(IEnumerable<MetadataModel> metadataModels)
        {
            Console.WriteLine("DataBuilder: Processing MetadataModel Data");
            //Console.WriteLine("Entered DataBuilder "+ metadataModels.ToString());

            //List for items and its permissions
            List<ItemsModel> itemsModels = new List<ItemsModel>();
            List<PermissionsModel> itemsPermissionModels = new List<PermissionsModel>();

            //List for comments and its permission
            List<CommentsModel> commentsModels = new List<CommentsModel>();
            List<PermissionsModel> commentsPermissionModels = new List<PermissionsModel>();

            //convert metadataModle to enumerator
            var metadataModelsEnumerator = metadataModels.GetEnumerator();
            itemsModels.Clear();

//            Console.WriteLine("Building data into respective items, comments, permissions...");
            //iterate through the IEnumerator
            while (metadataModelsEnumerator.MoveNext())
            {
                // Console.WriteLine(metadataModelsEnumerator.Current.GetType());
                MetadataModel metadata = metadataModelsEnumerator.Current;
              //  itemsModels.Clear();
                //Determine type of data
                switch (metadata.itemType)
                {
                    //Comment
                    case 2:
                    {
                        commentsModels.Add(new CommentsModel(metadata.itemId.ToString(), metadata.parentId,
                            metadata.itemType, metadata.ancestorId, metadata.ownerId, metadata.dateTime));

                        //Loop through acl and store data in permissionList
                        List<AccessControlsModel> accessControlList = metadata.accessControls;

                        foreach (AccessControlsModel accessControlsModel in accessControlList)
                        {
                            commentsPermissionModels.Add(new PermissionsModel(
                                accessControlsModel.GetUserId(),
                                accessControlsModel.IsCommentAllowed(),
                                accessControlsModel.IsModifyAllowed(),
                                isDeleteAllowed(metadata.ownerId.ToString())));
                            Console.WriteLine("\tUser\t" + accessControlsModel.GetUserId() + "\tModify?: " + accessControlsModel.IsCommentAllowed() + "\tComment?: " + accessControlsModel.IsCommentAllowed(), "\tDelete?: " + isDeleteAllowed(metadata.ownerId.ToString()));
                            }
                    }
                        break;
                    //Files and folders
                    default:
                    {
                       
                        itemsModels.Add(new ItemsModel(metadata.itemId.ToString(), metadata.parentId,
                            metadata.itemType, metadata.name));
                       // Console.WriteLine("Add File: " + metadata.itemId.ToString());
                        //Loop through acl and store data in permissionList
                        List<AccessControlsModel> accessControlList = metadata.accessControls;
                        foreach (AccessControlsModel accessControlsModel in accessControlList)
                        {
                            itemsPermissionModels.Add(new PermissionsModel(
                                metadata.itemId.ToString(),
                                accessControlsModel.IsCommentAllowed(),
                                accessControlsModel.IsModifyAllowed(),
                                isDeleteAllowed(metadata.ownerId.ToString())));
                           // Console.WriteLine("\tUser\t" + accessControlsModel.GetUserId() +  "\tModify?: " + accessControlsModel.IsCommentAllowed() + "\tComment?: " + accessControlsModel.IsCommentAllowed(), "\tDelete?: " + isDeleteAllowed(metadata.ownerId.ToString()));
                            }
                    }
                        break;
                }
            }


            //Store items and its permission into ACL
            DataCoreModel.GetInstance().SetItemsList(itemsModels);
            DataCoreModel.GetInstance().SetItemsPermissionsList(itemsPermissionModels);


            //Comments and its permissions into ACL
            DataCoreModel.GetInstance().SetCommentsList(commentsModels);
            DataCoreModel.GetInstance().SetCommentsPermissionsList(commentsPermissionModels);
        }

        /**
         * Check if ownerId == session owner id. Return true if its the same
         */
        private bool isDeleteAllowed(string ownerId)
        {
            if (ownerId == Session.getUserId())
            {
                return true;
            }
            else
            {
                return false;
            }
        }


    }
}