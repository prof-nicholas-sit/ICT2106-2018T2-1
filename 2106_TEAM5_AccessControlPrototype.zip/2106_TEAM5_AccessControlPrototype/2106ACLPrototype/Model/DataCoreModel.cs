﻿using _2106ACLPrototype.Model;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using DBLayer;
using DBLayer.DAL;
using MongoDB.Bson;

namespace _2106ACLPrototype.Model
{
    /**
     * This class is the main class of the Access Control Module
     * where it provides the main logic of the access control.
     * This class would allow interaction with the database to retrieve and update data to database.
     * This class would call the PackagerModel to package the data retrieved from database to the respective Item and Permission View
     */
    class DataCoreModel
    {
        private static DataCoreModel instance = null;

        // Used to determine if an update of the view is required, should be set when any updating of data layer occurs, and cleared when a retrieval happens
        private List<ItemsModel> itemsList;
        private List<CommentsModel> commentsList;
        private List<PermissionsModel> itemsPermissionsList;
        private List<PermissionsModel> commentsPermissionsList;

        private bool updateRequired;

        private DataCoreModel()
        {
            itemsList = new List<ItemsModel>();
            commentsList = new List<CommentsModel>();

            itemsPermissionsList = new List<PermissionsModel>();
            commentsPermissionsList = new List<PermissionsModel>();
            updateRequired = false;
        }

        // Get a reference to the sole instance of this class, creating it if necessary
        public static DataCoreModel GetInstance()
        {
            if (instance == null)
                instance = new DataCoreModel();

            return instance;
        }

        public List<ItemsModel> GetItemsList()
        {
            Console.WriteLine("ACLCore: Get Item List");
            return itemsList;
        }

        public void SetItemsList(List<ItemsModel> newItemsList)
        {
            itemsList = newItemsList;
        }

        public List<CommentsModel> GetCommentsList()
        {
            return commentsList;
        }

        public void SetCommentsList(List<CommentsModel> newCommentsList)
        {
            commentsList = newCommentsList;
        }

        public void SetItemsPermissionsList(List<PermissionsModel> newItemsPermissionsList)
        {
            itemsPermissionsList = newItemsPermissionsList;
        }

        public void SetCommentsPermissionsList(List<PermissionsModel> newCommentsPermissionsList)
        {
            commentsPermissionsList = newCommentsPermissionsList;
        }

        public bool CheckItemsPermissionsList(string itemId, string operation)
        {
            foreach (PermissionsModel itemPermissions in itemsPermissionsList)
            {
                if (itemPermissions.GetItemId().Equals(itemId))
                {
                    switch (operation)
                    {
                        case ACLUtils.ACTION_COMMENT:
                            return itemPermissions.IsCommentAllowed();
                        case ACLUtils.ACTION_MODIFY:
                            return itemPermissions.IsModifyAllowed();
                        case ACLUtils.ACTION_DELETE:
                            return itemPermissions.IsDeleteAllowed();
                    }
                }
            }

            return false;
        }

        public bool CheckCommentsPermissionsList(string commentId, string operation)
        {
            foreach (PermissionsModel commentPermissions in commentsPermissionsList)
            {
                if (commentPermissions.GetItemId().Equals(commentId))
                {
                    switch (operation)
                    {
                        case ACLUtils.ACTION_COMMENT:
                            return commentPermissions.IsCommentAllowed();
                        case ACLUtils.ACTION_MODIFY:
                            return commentPermissions.IsModifyAllowed();
                        case ACLUtils.ACTION_DELETE:
                            return commentPermissions.IsDeleteAllowed();
                    }
                }
            }

            return false;
        }

        /**
         * Called by manager to get items form database and store it into acl
         */
        public void GetItems(string currentFolderId)
        {
            Console.WriteLine("ACLModel: Get Items from database");
            //Read data from database
            ReadDataLayer(currentFolderId);
        }

        public void GetItemsByID(string currentFolderId)
        {
            Console.WriteLine("ACLModel: Get Item By ID from Mongo Db");
            //Read data from database
            ReadDataLayerByID(currentFolderId);
        }

        /**
        * Called by manager to get items form database and store it into acl
        */
        public void GetComments(string currentFolderId)
        {
            //Read data from database
            ReadDataLayer(currentFolderId);
        }

        /**
        *  Read data from database. This method reads the folder id, retrieves it from the database
        *  and packages the data into respective items,comments and permission list and stores it in the ACL
        */
        public void ReadDataLayer(string currentFolderId)
        {
            Console.WriteLine("ACLModel: Reading from Mongo Db");
            var enumarableContent = new MetadataGateway(new DbObj()).GetChildren(currentFolderId);
            Console.WriteLine("ACLModel: Data Retrieved from Mongo Db");
            if (enumarableContent != null)
            {
                //Process data from database
                var dataBuilder = new DataBuilder();
                dataBuilder.ProcessData(enumarableContent);
            }
            else {

                Console.WriteLine("Debug error: null value");
            }

            //Set flag that data is processed
            updateRequired = true;
        }

        public void ReadDataLayerByID(string currentFolderId)
        {
            Console.WriteLine("ACLModel: Reading from Mongo Db by ID");
            var enumarableContent = new MetadataGateway(new DbObj()).GetChildrenById(currentFolderId);
            Console.WriteLine("ACLModel: Data Retrieved from Mongo Db");
            if (enumarableContent != null)
            {
                //Process data from database
                var dataBuilder = new DataBuilder();
                dataBuilder.ProcessData(enumarableContent);
            }

            //Set flag that data is processed
            updateRequired = true;
        }

        /**
        *  
        */
        public void InsertDataLayer(string currentFolderId, ItemsModel newItem)
        {
            //connect to gatewaya
            DbObj dbObj = new DbObj();
            MetadataGateway metadataGateway = new MetadataGateway(dbObj);

            // insert default permission for owner
            AccessControlsModel acModel1 = new AccessControlsModel( Session.getUserId() , true, true);
            List<AccessControlsModel> acList = new List<AccessControlsModel>();

            acList.Add(acModel1);

            int type = newItem.GetItemType();

            MetadataModel metadataModel = new MetadataModel( new ObjectId(newItem.GetId()), Session.getUserId(), newItem.GetName(),
               type, DateTime.Now, "", newItem.GetParentId(), acList);

            Console.WriteLine("ACLModel: Inserting Data to Mongo Db");

            metadataGateway.Insert(metadataModel);
            metadataGateway.Save();
            updateRequired = true;
        }

        /**
        *  Update data in database
        */
        public void UpdateDataLayer(string currentFolderId, ItemsModel existingItem)
        {
            //connect to gatewaya
            DbObj dbObj = new DbObj();
            MetadataGateway metadataGateway = new MetadataGateway(dbObj);

            // insert default permission for owner
            AccessControlsModel acModel1 = new AccessControlsModel(Session.getUserId(), true, true);
            List<AccessControlsModel> acList = new List<AccessControlsModel>();

            acList.Add(acModel1);

            int type = existingItem.GetItemType();

            MetadataModel metadataModel = new MetadataModel(new ObjectId(existingItem.GetId()), Session.getUserId(), existingItem.GetName(),
               type, DateTime.Now, "", existingItem.GetParentId(), acList);

            Console.WriteLine("ACLModel: Updating data from Mongo Db");


            metadataGateway.Update(metadataModel);
            metadataGateway.Save();
            updateRequired = true;
        }

        /**
        * Delete data from database
        */
        public void DeleteDataLayer(ItemsModel existingItem)
        {
            //connect to gatewaya
            DbObj dbObj = new DbObj();
            MetadataGateway metadataGateway = new MetadataGateway(dbObj);
            // insert default permission for owner
            AccessControlsModel acModel1 = new AccessControlsModel(Session.getUserId(), true, true);
            List<AccessControlsModel> acList = new List<AccessControlsModel>();

            acList.Add(acModel1);
            Console.WriteLine("ACLModel: Deleting data from Mongo Db");

            int type = existingItem.GetItemType();

            MetadataModel metadataModel = new MetadataModel(new ObjectId(existingItem.GetId()),null , null,
               type, DateTime.Now, null, null, null); 

            metadataGateway.Delete(metadataModel);
            metadataGateway.Save();
            updateRequired = true;
        }

      

        /**
        *  Update data in database
        */
        public void UpdatePermissionDataLayer(string currentFolderId, AccessControlsModel acModel)
        {
            //connect to gatewaya
            DbObj dbObj = new DbObj();
            MetadataGateway metadataGateway = new MetadataGateway(dbObj);
            
            List<AccessControlsModel> acList = new List<AccessControlsModel>();
            
            //this will get the item
            MetadataModel metadataModel = metadataGateway.SelectById(currentFolderId);

            acList = metadataModel.accessControls;

            //insert the updated permission for user X
            acList.Add(acModel);

            Console.WriteLine("ACLModel: Updating permission of item from Mongo Db");
            //reassign the access Control list to the metadatamodel
            metadataModel.accessControls = acList;

            metadataGateway.Update(metadataModel);
            metadataGateway.Save();
            updateRequired = true;
        }

        
    }
}