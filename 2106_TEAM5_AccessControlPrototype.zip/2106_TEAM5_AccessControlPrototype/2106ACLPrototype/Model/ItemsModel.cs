﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _2106ACLPrototype.Model
{
    class ItemsModel : AbstractDataModel
    {
        private string name { get; set; }

        public ItemsModel(string id, string parentId, int itemType, string name) : base(id, parentId, itemType)
        {
            this.name = name;
        }

        public string GetName()
        {
            return this.name;
        }

        public void SetName(string name)
        {
            this.name = name;
        }
    }
}
