﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _2106ACLPrototype.Model
{
    //PERMISSIONS FOR Files/fileders and comments
    class PermissionsModel
    {
        private string itemId { get; set; }
        private bool commentAllowed { get; set; }
        private bool modifyAllowed { get; set; }
        private bool deleteAllowed { get; set; }

        public PermissionsModel(string itemId, bool commentAllowed, bool modifyAllowed, bool deleteAllowed)
        {
            this.itemId = itemId;
            this.commentAllowed = commentAllowed;
            this.modifyAllowed = modifyAllowed;
            this.deleteAllowed = deleteAllowed;
        }

        public string GetItemId()
        {
            return this.itemId;
        }

        public void SetItemId(string itemId)
        {
            this.itemId = itemId;
        }

        public bool IsCommentAllowed()
        {
            return this.commentAllowed;
        }

        public void SetCommentAllowed(bool commentAllowed)
        {
            this.commentAllowed = commentAllowed;
        }

        public bool IsModifyAllowed()
        {
            return this.modifyAllowed;
        }

        public void SetModifyAllowed(bool modifyAllowed)
        {
            this.modifyAllowed = modifyAllowed;
        }

        public bool IsDeleteAllowed()
        {
            return this.deleteAllowed;
        }

        public void SetDeleteAllowed(bool deleteAllowed)
        {
            this.deleteAllowed = deleteAllowed;
        }
    }
}
