﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _2106ACLPrototype.Model
{
    //Comments
    class CommentsModel : AbstractDataModel
    {
        private string ancestorId;
        private string userId;
        private DateTime dateTime;

        public CommentsModel(string id, string parentId, int itemType, string ancestorId, string userId, DateTime dateTime) : base(id, parentId, itemType)
        {
            this.ancestorId = ancestorId;
            this.userId = userId;
            this.dateTime = dateTime;
        }

        public string GetAncestorId()
        {
            return this.ancestorId;
        }

        public void SetAncestorId(string ancestorId)
        {
            this.ancestorId = ancestorId;
        }

        public string GetUserId()
        {
            return this.userId;
        }

        public void SetUserId(string userId)
        {
            this.userId = userId;
        }

        public DateTime GetDateTime()
        {
            return this.dateTime;
        }

        public void SetDateTime(DateTime dateTime)
        {
            this.dateTime = dateTime;
        }
    }
}
