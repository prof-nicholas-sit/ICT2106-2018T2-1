﻿using System;
using System.Collections.Generic;
using System.Text;
using DBLayer;// to use metadata model
using _2106ACLPrototype.Model;
using _2106ACLPrototype.Controller;
using MongoDB.Bson;

namespace _2106ACLPrototype
{
    //Classes that is not part of the Access Control module would be stored here

    
    class Session
    {
        public Session() {
            Console.WriteLine("Instantiating Session.");
        }
        public static string getUserId()
        {
            return "ryan@email.com";
        }
    }

    class TypesetterStub {

        CheckPermissionsManager _checkPermissionsManager = new CheckPermissionsManager();

        public string Item { set; get; }
        public string Comments { set; get; }

        public TypesetterStub() {
            Console.WriteLine("Instantiating Typesetter Stub.");
        }

        public void RequestItemPermission(string permissionID, string action) {
            
            Console.WriteLine(_checkPermissionsManager.CheckItemPermission(permissionID, action));

        }
        /*
        public void RequestCommentPermission(string permissionID, string action) {

            Console.WriteLine("Type setter is requesting for comments permission.");

            Console.WriteLine(_checkPermissionsManager.CheckCommentPermission(permissionID, action));

            Console.WriteLine("************** End of Operation**************");
        }
        */
        
    }

    class FilesystemStub {
        
        DataRequestManager dataRequestManager = new DataRequestManager();
        ItemsManager _itemsManager = new ItemsManager();
        string email;
        string fileName;
        ObjectId objId;
        string parentID;

        public FilesystemStub()
        {
            Console.WriteLine("Instantiating Filesystem Stub");
        }
        public void GetItem(string requestID){

            Console.WriteLine("File System GetItem: " + requestID);

            //request for list of item from data request manager
            List<ItemsModel> itemsList = dataRequestManager.RequestItems(requestID);

            Console.WriteLine("File System Display Retrieved Data");
            foreach (ItemsModel item in itemsList)
            {
                string itemtypestring = (item.GetId() == "0") ? "folder" : "file";

                Console.WriteLine("Name:" + item.GetName() + "\tID:"+item.GetId()+"\tType"+item.GetType());

            }
            Console.WriteLine("************** End of Operation**************");

        }

        public void GetItemByID(string requestID)
        {

            Console.WriteLine("File System GetItem: " + requestID);

            //request for list of item from data request manager
            List<ItemsModel> itemsList = dataRequestManager.RequestItemsByID(requestID);

            Console.WriteLine("File System Display Retrieved Data");
            foreach (ItemsModel item in itemsList)
            {
                string itemtypestring = (item.GetId() == "0") ? "folder" : "file";

                Console.WriteLine("Name:" + item.GetName() + "\tID:" + item.GetId() + "\tType" + item.GetType());

            }
            Console.WriteLine("************** End of Operation**************");

        }

        public void CreateItem(){

            // file system has a list of metadata of items the user can see, they will create a item with these values
            // for this case we simulate them creating the file with these parameters
            email = Session.getUserId();
            fileName = "2106_PreetyPrinter";
            objId = ObjectId.GenerateNewId();
            parentID = "5ac60ec3dc25a030e5125193";

            Console.WriteLine("File system module creates a file with parameters such as /n"
                +"id:"+objId+"\n"
                +"parentid:"+ parentID+"\n"
                +"type:"+ 1 +"\n"
                +"name:"+ fileName+"\n");

            //the meta data for the item is created by filesystem here and sent to the AC module's manager
            ItemsModel newFile = new ItemsModel(objId.ToString(),parentID, 1, fileName);
            bool result = _itemsManager.CreateItem(newFile);

            if (result == true)
            {
                Console.WriteLine("Successfully created item");
                
            }
            else {
                Console.WriteLine("failed to created item");
            }

        }
        public void UpdateItem(){
            //file system has the details of the item they want to modify, they will
            //create a item and poppulate it will all the item's details only only edit the field they wish to change.

            //for this case we simulate modifying the file that was created previously

            fileName = "2106 edited";

            ItemsModel newFile = new ItemsModel(objId.ToString(), parentID, 1, fileName);
            bool result = _itemsManager.EditItem(newFile);

            if (result == true)
            {
                Console.WriteLine("Successfully created item");

            }
            else
            {
                Console.WriteLine("failed to created item");
            }

        }
        public void DeleteItem(){
            // file system has a list of metadata of items the user can see, they will
            // create a item with the id of the file they want to delte

            // for this case we simulate  deleting the file that was created previously
        
            //the meta data for the item is created by filesystem here and sent to the AC module's manager
            ItemsModel newFile = new ItemsModel(objId.ToString(), parentID, 1, fileName);
            bool result = _itemsManager.DeleteItem(newFile);

            if (result == true)
            {
                Console.WriteLine("Successfully created item");

            }
            else
            {
                Console.WriteLine("failed to created item");
            }
        }
     
    }
    
}
