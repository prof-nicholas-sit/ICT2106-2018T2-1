﻿using _2106ACLPrototype.Controller;
using _2106ACLPrototype.Model;
using System;

using DBLayer.DAL;

namespace _2106ACLPrototype.Model
{
    class Program
    {
        //MAIN PROGRAM FLOW
        static void Main(string[] args)
        {
            //controller
            CheckPermissionsManager checkPermissionManager = new CheckPermissionsManager();
            PermissionsManager permissionsManager = new PermissionsManager();
            CommentsManager commentsManager = new CommentsManager();
            ItemsManager itemsManager = new ItemsManager();

            //model
            DataCoreModel ACLCore = DataCoreModel.GetInstance();
            DataBuilder dataBuilder = new DataBuilder();

            //data layer instantiation
            var db = new DbObj();
            var accGateway = new AccountGateway(db);
            var metadataGateway = new MetadataGateway(db);

            //stub instantiation
            TypesetterStub typesetterStub = new TypesetterStub();
            FilesystemStub filesystemStub = new FilesystemStub();

            Console.WriteLine();
            Console.WriteLine("Access Control Module Test");
            Console.WriteLine("FILE SYSTEM MODULE OPERATIONS:");
            Console.WriteLine("******************************************************");
            Console.WriteLine("1 : Get user root folder");
            Console.WriteLine("2 : Go into a sub folder");
            Console.WriteLine("3 : Create file");
            Console.WriteLine("4 : Update file");
            Console.WriteLine("5 : Delete file");
            Console.WriteLine("******************************************************");
            Console.WriteLine("TYPESETTER MODULE OPERATIONS");
            Console.WriteLine("******************************************************");
            Console.WriteLine("6 : Check permission item(File/Folder)");
            Console.WriteLine("******************************************************");
            
            Console.WriteLine("Please select one of the options above.");
            Console.WriteLine("Type \"exit\" to quit");


            Console.WriteLine("User Logged in as "+ Session.getUserId());

            while (true) {

                String stubCommand = Console.ReadLine().ToString();

                Console.WriteLine();

                switch (stubCommand)
                {

                    case "1":

                        Console.WriteLine("This case simulates the filesystem operation to retrive the metadata of the items in the root folder\n");
                        
                        //set to root
                        //file system sub simulates calling the manager to get data for root
                        filesystemStub.GetItem("root");
                       
                        break;

                    case "2": /*sub directory*/
                        
                        Console.WriteLine("This case simulate the filesystem operation to retrive the metadata of files/folders in sub directories\n");

                        Console.WriteLine("Please enter a folder ID");

                        string subDirectoryID = Console.ReadLine().ToString();
                        filesystemStub.GetItemByID(subDirectoryID);


                        break;
                    case "3":// create item

                        Console.WriteLine("This case simulate the filesystem operation to create an item in the root folder of the user.");

                        filesystemStub.CreateItem();

                        Console.WriteLine("Please run case 1 to see results of create\n");


                        Console.WriteLine("************** End of Operation**************");

                        break;
                    case "4": //update items

                        Console.WriteLine("This case simulate the filesystem operation to update an item in the root folder of the user.");
                        Console.WriteLine("We will be updating the name of the file that was create in case 3");

                        filesystemStub.UpdateItem();

                        Console.WriteLine("Please run case 1 to see results of update\n");


                        Console.WriteLine("************** End of Operation**************");
                        break;
                    case "5": //delete items

                        Console.WriteLine("This case simulate the filesystem operation to delte an item in the root folder of the user.");
                        Console.WriteLine("We will be deleting the file that was create in case 3");

                        filesystemStub.DeleteItem();

                        // with a metadata object
                        //hardcoded folderid for test
                        var metadata = metadataGateway.SelectById("5ac5e317dc25a02f88757f0e");
                        Console.WriteLine("Please run case 1 to see results of delete\n");


                        Console.WriteLine("************** End of Operation**************");
                        break;

                    case "6": //update items
                        Console.WriteLine("This case simulate the typesetter operation to check if the \n user has permission to perform an action on a file/folder");
                        Console.WriteLine("There are 3 types of actions modify, delete and comment \n we will perform checks for all 3 methods in this case in this sequence /n" +
                            "1: Modify permission\n" +
                            "2: Delete permission\n"+
                            "3: Comment permission\n");
                        Console.WriteLine("Permissions for file f, with id of 5ac60ec3dc25a030e512519c");
                        Console.Write("1: ");

                        typesetterStub.RequestItemPermission("5ac60ec3dc25a030e512519c", "MODIFY" );
                        Console.Write("2: ");
                        typesetterStub.RequestItemPermission("5ac60ec3dc25a030e512519c", "DELETE");
                        Console.Write("3: ");
                        typesetterStub.RequestItemPermission("5ac60ec3dc25a030e512519c", "COMMENT");

                        Console.WriteLine("************** End of Operation**************");
                        break;

                    case "exit":
                        return;
                    default: /*"Unknown command":*/

                        Console.WriteLine("Unknown command: " + stubCommand);
                        Console.WriteLine("Please select one of the options above.");

                        break;

                }


            }




            /*

            Console.WriteLine("Show Root level");

            //Get root level items
            if (ACLCore.GetItems("root"))
            {
                //Get items
                foreach (PermissionsModel permissionsModel in permissionsManager.GetIt())
                {
                    Console.WriteLine("File: " + itemsModel.GetName());
                }
            }
            Console.ReadKey();
    */

        }
    }
}
