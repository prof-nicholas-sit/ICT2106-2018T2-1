﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _2106ACLPrototype
{
    public class ACLUtils
    {
        public const string ACTION_COMMENT = "COMMENT";
        public const string ACTION_MODIFY = "MODIFY";
        public const string ACTION_DELETE = "DELETE";
    }
}
