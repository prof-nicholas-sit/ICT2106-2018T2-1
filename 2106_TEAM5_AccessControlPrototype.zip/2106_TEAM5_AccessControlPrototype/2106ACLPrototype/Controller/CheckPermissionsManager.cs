﻿using _2106ACLPrototype.Model;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace _2106ACLPrototype.Controller
{
    /**
    * This class would act an internal input controller to be used to check whether a requested user action is allowed to be performed.
    */
    class CheckPermissionsManager
    {
        /**
         * Call Permissions View to determine if the requested operation is allowed to be performed based on the user's permissions
         * Return true if allowed else false
         */
        public bool CheckItemPermission(string itemId, string operation)
        {
            return DataCoreModel.GetInstance().CheckItemsPermissionsList(itemId, operation);
        }


        /**
         * Call Permissions View to determine if the requested operation is allowed to be performed based on the user's permissions
         * Return true if allowed else false
         */
        public bool CheckCommentPermission(string commentId, string operation)
        {
            return DataCoreModel.GetInstance().CheckCommentsPermissionsList(commentId, operation);
        }
    }
}
