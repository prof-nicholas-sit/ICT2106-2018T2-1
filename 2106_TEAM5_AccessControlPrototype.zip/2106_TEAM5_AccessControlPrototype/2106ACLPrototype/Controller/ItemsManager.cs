﻿using _2106ACLPrototype.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace _2106ACLPrototype
{
    /**
     * This class would act as an input controller to allow FileManager to manage items in the database.
     * This class would provide the Create, Update, Delete operation for items in database.
     */
    class ItemsManager

    {
      
        /**
         * This would be called by the File Manager Module to create an item in the db
         * Returns true if file created, false if unable to create file
         */
        public bool CreateItem(ItemsModel item)
        {
            Console.WriteLine("ItemsManager: creating item");
            DataCoreModel.GetInstance().InsertDataLayer(item.GetParentId(), item);
            return true;
        }

        /**
         * This would be called by the File Manager Module to edit an item in the db
         * Returns true if file edited, false if unable to edit file
         */
        public bool EditItem(ItemsModel item)
        {
            DataCoreModel.GetInstance().UpdateDataLayer(item.GetParentId(), item);
            return true;
        }

        /**
         * This would be called by the File Manager Module to delete an item in the db
         * Returns true if file deleted, false if unable to delete file
         */
        public bool DeleteItem(ItemsModel item)
        {
            DataCoreModel.GetInstance().DeleteDataLayer(item);
            return true;
        }
    }
}
