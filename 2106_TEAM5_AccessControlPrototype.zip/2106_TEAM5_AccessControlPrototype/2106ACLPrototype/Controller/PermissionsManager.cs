﻿using System;
using System.Collections.Generic;
using System.Text;
using _2106ACLPrototype.Model;
using DBLayer;

namespace _2106ACLPrototype.Controller
{
    /**
     * This class would act as an input controller to allow FileManager to manage items in the database.
     * This class would provide the Create, Update, Delete operation for items in database.
     */
    class PermissionsManager
    {

        /**
         * This would be called by the File Manager Module to assign another person to the access control list of the item
         * Returns true if assignment succeeded, false if unable to assign
         */
        public bool AssignPermissions(string folderID, string userID, PermissionsModel permissionsModel)
        {

            // insert default permission for owner
            AccessControlsModel acModel = new AccessControlsModel(userID, permissionsModel.IsCommentAllowed(), permissionsModel.IsDeleteAllowed());

            DataCoreModel.GetInstance().UpdatePermissionDataLayer(permissionsModel.GetItemId(),acModel);


            return true;
        }

        /**
         * This would be called by the File Manager Module to edit another person's permissions in the access control list of the item
         * Returns true if editing succeeded, false if unable to edit
         */
        public bool EditPermissions(string folderID, string userID, PermissionsModel permissionsModel)
        {
            // insert default permission for owner
            AccessControlsModel acModel = new AccessControlsModel(userID, permissionsModel.IsCommentAllowed(), permissionsModel.IsDeleteAllowed());

            DataCoreModel.GetInstance().UpdatePermissionDataLayer(permissionsModel.GetItemId(), acModel);

            return true;
        }

        /**
         * This would be called by the File Manager Module to delete another person from the access control list of the item
         * Returns true if deleted, false if unable to delete
         */
        public bool RemovePermissions(string folderID, string userID, PermissionsModel permissionsModel)
        {
            // insert default permission for owner
            AccessControlsModel acModel = new AccessControlsModel(userID, permissionsModel.IsCommentAllowed(), permissionsModel.IsDeleteAllowed());

            DataCoreModel.GetInstance().UpdatePermissionDataLayer(permissionsModel.GetItemId(), acModel);

            return true;
        }
    }
}
