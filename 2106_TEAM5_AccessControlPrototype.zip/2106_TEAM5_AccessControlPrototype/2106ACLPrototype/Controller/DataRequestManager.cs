﻿using System;
using System.Collections.Generic;
using System.Text;
using _2106ACLPrototype.Model;

namespace _2106ACLPrototype.Controller
{
    class DataRequestManager
    {
     
        //takes in both folder
        public List<ItemsModel> RequestItems(String folderID) {
            Console.WriteLine("DataRequestManager: Requesting items from ACLModel");
            if (folderID == "root") {

                folderID = Session.getUserId();
                
            }

            //get instance of ACLModel   
            DataCoreModel.GetInstance().GetItems(folderID);
            Console.WriteLine("DataRequestManager: Requesting retrieved items");
            return  DataCoreModel.GetInstance().GetItemsList();

        }

        public List<ItemsModel> RequestItemsByID(String folderID)
        {
            Console.WriteLine("DataRequestManager: Requesting items by ID from ACLModel");
            //get instance of ACLModel   
            DataCoreModel.GetInstance().GetItemsByID(folderID);
            Console.WriteLine("DataRequestManager: Requesting retrieved items");
            return DataCoreModel.GetInstance().GetItemsList();

        }

        //ancestorID = file id
        public List<CommentsModel> RequestComments(String ancestorID)
        {

            return null;

        }

    }
}
