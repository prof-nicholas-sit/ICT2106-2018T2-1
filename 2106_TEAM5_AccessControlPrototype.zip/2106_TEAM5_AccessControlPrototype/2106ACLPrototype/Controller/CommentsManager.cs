﻿using _2106ACLPrototype.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace _2106ACLPrototype.Controller
{
    /**
     * This class would act as an input controller to allow FileManager to manage comments in the database.
     * This class would provide the Create, Update, Delete operation for comments in database.
     */
    class CommentsManager
    {
        /**
         * This would be called by the File Manager Module to create a comment in the db
         * Returns true if comment created, false if unable to create comment
         */
        public bool AddComment(string fieldId, CommentsModel comments)
        {
            return true;
        }

        /**
         * This would be called by the File Manager Module to edit a comment in the db
         * Returns true if comment edited, false if unable to edit comment
         */
        public bool EditComment(string fieldId, CommentsModel comments)
        {
            return true;
        }

        /**
         * This would be called by the File Manager Module to delete a comment in the db
         * Returns true if comment deleted, false if unable to delete comment
         */
        public bool DeleteComment(string fieldId, CommentsModel comments)
        {
            return true;
        }
    }
}
