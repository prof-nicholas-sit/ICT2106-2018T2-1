﻿using System;
using MongoDB.Bson;
using System.Collections.Generic;
using MongoDB.Bson.Serialization.Attributes;

namespace DBLayer
{
    public class MetadataModel
    {
        private ObjectId objectId;
        private string v1;
        private string v2;
        private string v3;
        private string v4;
        private List<AccessControlsModel> acList;

        [BsonId]
        [BsonElement(elementName:"_id")]
        public ObjectId itemId { get; set; }
        [BsonElement(elementName:"OwnerID")]      
        public string ownerId { get; set; }
        [BsonElement(elementName:"Name")]
        public string name { get; set; }
        [BsonElement(elementName:"ItemType")]
        public int itemType { get; set; }
        [BsonElement(elementName:"DateTime")]
        [BsonRepresentation(BsonType.DateTime)]
        public DateTime dateTime { get; set; }
        [BsonElement(elementName:"AncestorID")]
        public string ancestorId { get; set; }
        [BsonElement(elementName:"ParentID")]
        public string parentId { get; set; }
        [BsonElement(elementName:"AccessControl")]
        public List<AccessControlsModel> accessControls { get; set; }
        
        public MetadataModel(ObjectId itemId, string ownerId, string name, int itemType, DateTime dateTime, string ancestorId, string parentId, List<AccessControlsModel> accessControls)
        {
            this.itemId = itemId;      
            this.ownerId = ownerId;
            this.name = name;
            this.itemType = itemType;
            this.dateTime = dateTime;
            this.ancestorId = ancestorId;
            this.parentId = parentId;
            this.accessControls = accessControls;
        }

        public MetadataModel(ObjectId objectId, string v1, string v2, DateTime dateTime, string v3, string v4, List<AccessControlsModel> acList)
        {
            this.objectId = objectId;
            this.v1 = v1;
            this.v2 = v2;
            this.dateTime = dateTime;
            this.v3 = v3;
            this.v4 = v4;
            this.acList = acList;
        }
    }
}